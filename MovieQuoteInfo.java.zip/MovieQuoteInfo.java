package mpllabs.moviequoteinfo;

public class MovieQuoteInfo 
{

    public static void main(String[] args) {
        System.out.println("I want to see and understand the world outside. I don't want to die inside these walls without knowing what's out there!");
        System.out.println("Attack on Titan");
        System.out.println("Eren Yeager");
        System.out.println("September 18 2013");
    }
}
