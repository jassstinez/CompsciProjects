package mpllabs.songlyrics;

public class SongLyrics 

{
   public static void main (String[]args)
   {
       System.out.println( "L is for the way you look at me, ");
       System.out.println( "O is for the only one I see.");
       System.out.println( "V is very, very extraordinary.");
       System.out.println( "E is even more than anyone that you adore can...");
   }
}
    
   
